<?php
session_start();
require '../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
  header('Location:../login.php');
  die();
}
require '../connection.php';
?> 
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        
        if (!empty($_GET["dato"])) {
        //$numeroGiorni <= 0 && $array[$i]['Stato'] != "pagata" 
        $dato = mysqli_real_escape_string($conn,  $_GET["dato"]); 
        $id = mysqli_real_escape_string($conn,  $_GET["id"]); 
        $tabella = mysqli_real_escape_string($conn,  $_GET["nome-tabella"]); 
        $option = mysqli_real_escape_string($conn,  $_GET["option"]); 
          echo $dato . $option . $id;
          $currentDate = date("Y-m-d");
        $sql = "UPDATE $tabella SET Stato = '$option', Metodo = '$dato', DataPagamento = '$currentDate' WHERE id = $id";
        if ($conn->query($sql) === TRUE) {
          echo "Dati inseriti con successo nel database";
        } else {
            echo "Errore nell'inserimento dei dati nel database: " . $conn->error;
        }
                    
      
                            // Esegui la query SQL
        header('Location:fatture.php');
        die();
        } else {
          echo "Nessun valore inserito";
        }            
        header('Location:fatture.php');
        die();
    } 
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        //$numeroGiorni <= 0 && $array[$i]['Stato'] != "pagata" 
        $option = mysqli_real_escape_string($conn,  $_POST["option"]);
        $nome_tabella = mysqli_real_escape_string($conn,  $_POST["nome-tabella"]);
        $id = mysqli_real_escape_string($conn, $_POST["id"]);
       // echo $id . $option;
        ?>
    <?php
    if ($option == "pagata") {
    ?>
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <meta name="description" content="nothing">
            <meta name="author" content="anonymous">
            <style>
              body {
                  display: flex;
                  justify-content: center;
                  align-items: center;
                  height: 100vh;
                  margin: 0;
              }
              form {
                  width: 300px; /* Adjust the width as needed */
                  padding: 20px;
                  border: 1px solid #ccc;
                  border-radius: 5px;
                  background-color: #f9f9f9;
              }
              input[type="text"] {
                  width: 100%;
                  padding: 8px;
                  margin: 6px 0;
                  box-sizing: border-box;
                  border: 1px solid #ccc;
                  border-radius: 4px;
              }
              input[type="submit"] {
                  width: 100%;
                  background-color: #0d6efd;
                  color: white;
                  padding: 10px 20px;
                  border: none;
                  border-radius: 4px;
                  cursor: pointer;
              }
              input[type="submit"]:hover {
                  background-color: #45a049;
              }
          </style>
          </head>
          <body>
              <form action="ricezione_fatture.php" method="get">
                <label for="dato">Inserisci il metodo di pagamento:</label><br>
                <input type="text" id="dato" name="dato" required><br><br>
                <input type="hidden" id="campoNascosto" name="option" value="<?php echo $option;?>">
                <input type="hidden" id="campoNascosto" name="id" value="<?php echo $id;?>">
                <input type="hidden" id="campoNascosto" name="nome-tabella" value="<?php echo $nome_tabella;?>">
                <input type="submit" value="Invia">
              </form>
          </body>
        </html>

        <?php
          } else {
        ?>

    <?php
        
        $sql = "SELECT Scadenza FROM $nome_tabella WHERE id = '$id'";
        $result = $conn->query($sql);

      // Verifica se ci sono risultati
      if ($result->num_rows > 0) {
          // Itera sui risultati e salvali nell'array
          while($row = $result->fetch_assoc()) {
              $scadenza = $row["Scadenza"];
          }
          // Ora $clienti contiene i nomi dei clienti di Roma
      } else {
          echo "Nessun risultato trovato";
      }

      $dataOdierna = new DateTime();
      $dataFutura = new DateTime($scadenza); // Creare un oggetto DateTime direttamente dalla stringa

      $differenza = $dataFutura->diff($dataOdierna); // Usare il metodo diff() su un oggetto DateTime

      $numeroGiorni = $differenza->days;
      if ($dataFutura < $dataOdierna) {
          $numeroGiorni = $numeroGiorni;
      }



        /*$dataOdierna = new DateTime($dataIns);
        $dataOdiernaCopia = clone $dataOdierna;

        $dataFutura = $dataOdiernaCopia->add(new DateInterval("P{$scadenza}D"));
            
        $dataFormattata = $dataFutura->format('d-m-Y');
        $dataOggi = new DateTime();
        $differenza = $dataFutura->diff($dataOggi);
          
        $numeroGiorni = $differenza->days;
        if ($dataFutura < $dataOggi) {
          $numeroGiorni = -$numeroGiorni;
        }*/



        echo $option;
        if (!empty($option) && !empty($id)) {
          if ($numeroGiorni > 7 && $option == "scaduta") {
            $option = "niente";
            $sql = "UPDATE $nome_tabella SET stato = '$option', metodo = '' WHERE id = $id";
            if ($conn->query($sql) === TRUE) {
              //echo "Dati inseriti con successo nel database";
            } else {
                //echo "Errore nell'inserimento dei dati nel database: " . $conn->error;
            }
          } elseif($numeroGiorni <= 7 && $option == "scaduta") {
              $sql = "UPDATE $nome_tabella SET stato = '$option', metodo = '' WHERE id = $id";
              if ($conn->query($sql) === TRUE) {
                //echo "Dati inseriti con successo nel database";
              } else {
                  //echo "Errore nell'inserimento dei dati nel database: " . $conn->error;
              }
          } else {
            $sql = "UPDATE $nome_tabella SET stato = '$option', metodo = '' WHERE id = $id";
            if ($conn->query($sql) === TRUE) {
              //echo "Dati inseriti con successo nel database";
          } else {
              //echo "Errore nell'inserimento dei dati nel database: " . $conn->error;
          }
          }
         
      
                            // Esegui la query SQL
        header('Location:fatture.php');
        die();
        } else {
          echo "Nessun valore inserito";
          echo "<p class=\"red\">Errore</p>";
          header('Location:fatture.php');
          die();
        }         
    } 
  } else {
    header('Location:fatture.php');
    die();
  }
?>
