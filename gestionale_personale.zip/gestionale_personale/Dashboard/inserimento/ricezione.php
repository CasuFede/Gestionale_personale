<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
  header('Location:../../login.php');
  die();
}
require '../../connection.php';

// Verifica se il form è stato inviato
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Verifica se sono stati inviati dati relativi all'immobile
    if (isset($_POST['immobile'])) {
        
        // Recupera i dati relativi all'immobile
        $immobile_id = $_POST['immobile'];
        
        // Verifica se è stata selezionata una categoria di spesa
        if (isset($_POST['categoria-tipo'])) {
            // Recupera il tipo di spesa selezionato
            $tipo_spesa = $_POST['categoria-tipo'];
            // A seconda del tipo di spesa selezionato, esegui le operazioni necessarie
            switch ($tipo_spesa) {
                
                case 'bolletta':
                    
                    // Verifica se sono stati inviati dati relativi alla bolletta
                    if (isset($_POST['motivo']) && isset($_POST['bolletta-costo']) && isset($_POST['bolletta-scadenza'])) {
                        
                        // Recupera i dati relativi alla bolletta
                        $motivo = $_POST['motivo'];
                        $importo = $_POST['bolletta-costo'];
                        $scadenza = $_POST['bolletta-scadenza'];
                        $bolletta_mese1 = $_POST['bolletta-mese1'] . "-01";
                        $bolletta_mese2 = $_POST['bolletta-mese2'] . "-01";


                        if ($_FILES["bolletta-file"]["error"] == UPLOAD_ERR_OK) {
                            // Percorso della cartella in cui salvare il file
                            $uploadDirectory = "fattureBolletta/";
                        
                            // Crea la cartella se non esiste
                            if (!file_exists($uploadDirectory)) {
                                mkdir($uploadDirectory, 0777, true);
                            }
                        
                            // Nome del file
                            $nomeFileOriginale = $_FILES["bolletta-file"]["name"];
                            $nomeFileTemporaneo = $_FILES["bolletta-file"]["tmp_name"];
                            
                            // Rinomina il file in modo univoco
                            $nomeFileUnico = uniqid() . '_' . $nomeFileOriginale;
                            $nomeFileDestinazione = $uploadDirectory . $nomeFileUnico;
                        
                            // Salva il file rinominato direttamente nel percorso di destinazione
                            if (move_uploaded_file($nomeFileTemporaneo, $nomeFileDestinazione)) {
                                echo "Il file $nomeFileOriginale è stato caricato con successo.";
                                
                                // Aggiungi il percorso del file al database
                                $dataOdierna = date("Y-m-d");
                                $query = "INSERT INTO bolletta (Motivo, DataIns, Importo, Scadenza, Stato, CodImmobile, mese1, mese2, percorso)
                                VALUES('$motivo', '$dataOdierna', '$importo', '$scadenza', 'niente', '$immobile_id', '$bolletta_mese1', '$bolletta_mese2', '$nomeFileDestinazione')";
                                if($conn->query($query) === TRUE){
                                    header('Location:invio.php');
                                    die();
                                } else {
                                    echo "Inserimento fattura errore".$conn->error;
                                }
                            } else {
                                echo "Si è verificato un errore durante il caricamento del file.";
                            }
                        } else {
                            echo "Si è verificato un errore durante l'upload del file.";
                        }
                        
                       
                        
                    } else {
                        // Gestisci il caso in cui mancano dati relativi alla bolletta
                        // (dipende dall'implementazione specifica)
                        
                    }
                    break;
                
                case 'manutenzione':
                    // Verifica se sono stati inviati dati relativi alla manutenzione
                    if (isset($_POST['manutenzione-motivo']) && isset($_POST['manutenzione-eseguita']) && isset($_POST['manutenzione-costo'])) {
                        
                        // Recupera i dati relativi alla manutenzione
                        $motivo = $_POST['manutenzione-motivo'];
                        $data_esecuzione = $_POST['manutenzione-eseguita'];
                        $spesa = $_POST['manutenzione-costo'];
                        
                        $query = "INSERT INTO manutenzione (Motivo, Data, Costo, CodImmobile)
                        VALUES('$motivo', '$data_esecuzione', '$spesa', '$immobile_id')";
                        if($conn->query($query) === TRUE){
                            header('Location:invio.php');
                            //$_SESSION['message2'] = "Riparazione inserita con successo";
                            die();
                        }else{
                            echo "Inserimento fattura errore".$conn->error;
                        }
                    } else {
                        // Gestisci il caso in cui mancano dati relativi alla manutenzione
                        // (dipende dall'implementazione specifica)
                    }
                    break;
                
                case 'rifiuti':
                    // Verifica se è stato inviato il costo della spesa dei rifiuti
                    if (isset($_POST['rifiuti-costo'])) {
                        
                        // Recupera il costo della spesa dei rifiuti
                        $costo_rifiuti = $_POST['rifiuti-costo'];
                        $anno_rifiuti = $_POST['rifiuti-anno'];
                        
                        $query = "INSERT INTO rifuiti (Spesa, CodImmobile, Anno)
                        VALUES('$costo_rifiuti', '$immobile_id', '$anno_rifiuti')";
                        if($conn->query($query) === TRUE){
                            header('Location:invio.php');
                            //$_SESSION['message2'] = "Riparazione inserita con successo";
                            die();
                        }else{
                            echo "Inserimento fattura errore".$conn->error;
                        }

                    } else {
                        // Gestisci il caso in cui manca il costo della spesa dei rifiuti
                        // (dipende dall'implementazione specifica)
                    }
                    break;
                
                // Aggiungi altri casi per gestire ulteriori tipi di spese se necessario
                
                default:
                    // Gestisci il caso in cui non è stato selezionato un tipo di spesa valido
                    // (dipende dall'implementazione specifica)
                    break;
            }
        } else {
            // Gestisci il caso in cui non è stata selezionata una categoria di spesa
            // (dipende dall'implementazione specifica)
        }
    } else {
        // Gestisci il caso in cui non sono stati inviati dati relativi all'immobile
        // (dipende dall'implementazione specifica)
    }
    
    // Gestisci i dati relativi ai veicoli, se presenti
    if (isset($_POST['veicolo'])) {
        
        // Recupera i dati relativi al veicolo
        $veicolo_id = $_POST['veicolo'];
        
        // Verifica se è stata selezionata una categoria di spesa per il veicolo
        if (isset($_POST['tipo'])) {
            
            // Recupera il tipo di spesa selezionato per il veicolo
            $tipo_spesa_veicolo = $_POST['tipo'];
            
            // A seconda del tipo di spesa selezionato per il veicolo, esegui le operazioni necessarie
            switch ($tipo_spesa_veicolo) {
                
                case 'assicurazione':
                    // Gestisci la spesa dell'assicurazione per il veicolo
                    // (dipende dall'implementazione specifica)
                    $assicurazione_tipo = $_POST['assicurazione-tipo'];
                    $assicurazione_costo = $_POST['assicurazione-costo'];
                    $assicurazione_scadenza = $_POST['assicurazione-scadenza'];

                    if ($_FILES["assicurazione-file"]["error"] == UPLOAD_ERR_OK) {
                        // Percorso della cartella in cui salvare il file
                        $uploadDirectory = "fattureAssicurazione/";
                    
                        // Crea la cartella se non esiste
                        if (!file_exists($uploadDirectory)) {
                            mkdir($uploadDirectory, 0777, true);
                        }
                    
                        // Nome del file
                        $nomeFileOriginale = $_FILES["assicurazione-file"]["name"];
                        $nomeFileTemporaneo = $_FILES["assicurazione-file"]["tmp_name"];
                        
                        // Rinomina il file in modo univoco
                        $nomeFileUnico = uniqid() . '_' . $nomeFileOriginale;
                        $nomeFileDestinazione = $uploadDirectory . $nomeFileUnico;
                    
                        // Salva il file rinominato direttamente nel percorso di destinazione
                        if (move_uploaded_file($nomeFileTemporaneo, $nomeFileDestinazione)) {
                            echo "Il file $nomeFileOriginale è stato caricato con successo.";
                            
                            // Aggiungi il percorso del file al database
                            $query = "INSERT INTO assicurazione (Tipo, Importo, Scadenza, CodVeicolo, percorso)
                        VALUES('$assicurazione_tipo', '$assicurazione_costo', '$assicurazione_scadenza', '$veicolo_id', '$nomeFileDestinazione')";;
                            if($conn->query($query) === TRUE){
                                header('Location:invio.php');
                                die();
                            } else {
                                echo "Inserimento fattura errore".$conn->error;
                            }
                        } else {
                            echo "Si è verificato un errore durante il caricamento del file.";
                        }
                    } else {
                        echo "Si è verificato un errore durante l'upload del file.";
                    }
                    break;
                
                case 'bollo':
                    // Gestisci la spesa del bollo per il veicolo
                    // (dipende dall'implementazione specifica)
                    $bollo_costo = $_POST['bollo-costo'];
                    $bollo_scadenza = $_POST['bollo-scadenza'];
                    
                    if ($_FILES["bollo-file"]["error"] == UPLOAD_ERR_OK) {
                        // Percorso della cartella in cui salvare il file
                        $uploadDirectory = "fattureBollo/";
                    
                        // Crea la cartella se non esiste
                        if (!file_exists($uploadDirectory)) {
                            mkdir($uploadDirectory, 0777, true);
                        }
                    
                        // Nome del file
                        $nomeFileOriginale = $_FILES["bollo-file"]["name"];
                        $nomeFileTemporaneo = $_FILES["bollo-file"]["tmp_name"];
                        
                        // Rinomina il file in modo univoco
                        $nomeFileUnico = uniqid() . '_' . $nomeFileOriginale;
                        $nomeFileDestinazione = $uploadDirectory . $nomeFileUnico;
                    
                        // Salva il file rinominato direttamente nel percorso di destinazione
                        if (move_uploaded_file($nomeFileTemporaneo, $nomeFileDestinazione)) {
                            echo "Il file $nomeFileOriginale è stato caricato con successo.";
                            
                            // Aggiungi il percorso del file al database
                            $query = "INSERT INTO bollo (Importo, percorso, Scadenza, CodVeicolo)
                    VALUES('$bollo_costo', '$nomeFileDestinazione', '$bollo_scadenza', '$veicolo_id')";
                            if($conn->query($query) === TRUE){
                                header('Location:invio.php');
                                die();
                            } else {
                                echo "Inserimento fattura errore".$conn->error;
                            }
                        } else {
                            echo "Si è verificato un errore durante il caricamento del file.";
                        }
                    } else {
                        echo "Si è verificato un errore durante l'upload del file.";
                    }
                    break;
                
                case 'riparazione':
                    // Gestisci la spesa della riparazione per il veicolo
                    // (dipende dall'implementazione specifica)
                    
                    $riparazione_motivo = $_POST['riparazione-motivo'];
                    $riparazion_costo = $_POST['riparazione-costo'];
                    $riparazion_metodo = $_POST['riparazione-metodo'];
                    if ($_FILES["riparazione-file"]["error"] == UPLOAD_ERR_OK) {
                        // Percorso della cartella in cui salvare il file
                        $uploadDirectory = "fattureRiparazione/";
                    
                        // Crea la cartella se non esiste
                        if (!file_exists($uploadDirectory)) {
                            mkdir($uploadDirectory, 0777, true);
                        }
                    
                        // Nome del file
                        $nomeFileOriginale = $_FILES["riparazione-file"]["name"];
                        $nomeFileTemporaneo = $_FILES["riparazione-file"]["tmp_name"];
                        
                        // Rinomina il file in modo univoco
                        $nomeFileUnico = uniqid() . '_' . $nomeFileOriginale;
                        $nomeFileDestinazione = $uploadDirectory . $nomeFileUnico;
                    
                        // Salva il file rinominato direttamente nel percorso di destinazione
                        if (move_uploaded_file($nomeFileTemporaneo, $nomeFileDestinazione)) {
                            echo "Il file $nomeFileOriginale è stato caricato con successo.";
                            
                            // Aggiungi il percorso del file al database
                            $query = "INSERT INTO riparazioni (Motivo, Importo, percorso, CodVeicolo, metodo)
                    VALUES('$riparazione_motivo', '$riparazion_costo', '$nomeFileDestinazione', '$veicolo_id', '$riparazion_metodo')";
                            if($conn->query($query) === TRUE){
                                header('Location:invio.php');
                                die();
                            } else {
                                echo "Inserimento fattura errore".$conn->error;
                            }
                        } else {
                            echo "Si è verificato un errore durante il caricamento del file.";
                        }
                    } else {
                        echo "Si è verificato un errore durante l'upload del file.";
                    }

                    break;
                case 'manutenzione1':
                    $manutenzione1_motivo = $_POST['manutenzione1-motivo'];
                    $manutenzione1_costo = $_POST['manutenzione1-costo'];
                    $manutenzione1_metodo = $_POST['manutenzione1-metodo'];
                    if ($_FILES["manutenzione1-file"]["error"] == UPLOAD_ERR_OK) {
                        // Percorso della cartella in cui salvare il file
                        $uploadDirectory = "fattureManutenzioni/";
                    
                        // Crea la cartella se non esiste
                        if (!file_exists($uploadDirectory)) {
                            mkdir($uploadDirectory, 0777, true);
                        }
                    
                        // Nome del file
                        $nomeFileOriginale = $_FILES["manutenzione1-file"]["name"];
                        $nomeFileTemporaneo = $_FILES["manutenzione1-file"]["tmp_name"];
                        
                        // Rinomina il file in modo univoco
                        $nomeFileUnico = uniqid() . '_' . $nomeFileOriginale;
                        $nomeFileDestinazione = $uploadDirectory . $nomeFileUnico;
                    
                        // Salva il file rinominato direttamente nel percorso di destinazione
                        if (move_uploaded_file($nomeFileTemporaneo, $nomeFileDestinazione)) {
                            echo "Il file $nomeFileOriginale è stato caricato con successo.";
                            
                            // Aggiungi il percorso del file al database
                            $query = "INSERT INTO manutenzione1 (Tipo, CodVeicolo, Importo, percorso, Metodo)
                                      VALUES('$manutenzione1_motivo', '$veicolo_id', '$manutenzione1_costo', '$nomeFileDestinazione', '$manutenzione1_metodo')";
                            if($conn->query($query) === TRUE){
                                header('Location:invio.php');
                                die();
                            } else {
                                echo "Inserimento fattura errore".$conn->error;
                            }
                        } else {
                            echo "Si è verificato un errore durante il caricamento del file.";
                        }
                    } else {
                        echo "Si è verificato un errore durante l'upload del file.";
                    }
                    
                    

                    $query = "INSERT INTO manutenzione1 (Tipo, CodVeicolo, Importo, percorso, Metodo)
                    VALUES('$manutenzione1_motivo', '$veicolo_id', '$manutenzione1_costo', '$targetPath', '$manutenzione1_metodo')";
                    if($conn->query($query) === TRUE){
                        header('Location:invio.php');
                        //$_SESSION['message2'] = "Riparazione inserita con successo";
                        die();
                    }else{
                        echo "Inserimento fattura errore".$conn->error;
                    }
                    break;
                case 'gestione':
                    $gestione_tipo = $_POST['gestione-tipo'];
                    $gestione_costo = $_POST['gestione-costo'];
                    $query = "INSERT INTO gestione (Tipo, Importo, CodVeicolo)
                    VALUES('$gestione_tipo', '$gestione_costo', '$veicolo_id')";
                    if($conn->query($query) === TRUE){
                        header('Location:invio.php');
                        //$_SESSION['message2'] = "Riparazione inserita con successo";
                        die();
                    }else{
                        echo "Inserimento fattura errore".$conn->error;
                    }
                    break;
                
                default:
                    // Gestisci il caso in cui non è stato selezionato un tipo di spesa valido per il veicolo
                    // (dipende dall'implementazione specifica)
                    break;
            }
        } else {
            // Gestisci il caso in cui non è stata selezionata una categoria di spesa per il veicolo
            // (dipende dall'implementazione specifica)
        }
    }
}

?>
