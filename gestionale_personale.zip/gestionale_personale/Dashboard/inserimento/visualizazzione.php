<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualizzazione-informazioni</title>
    <style>
    /* Layout generale */
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 1200px;
        margin: 20px auto;
        padding: 20px;
        background-color: #f9f9f9;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    /* Stili per i pulsanti */
    .btn {
        display: block;
        margin-bottom: 10px; /* Qui è il margin-bottom per i pulsanti */
        padding: 10px 20px;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    .btn:hover {
        background-color: #0056b3;
    }
    /* Stili per la tabella */
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        margin-bottom: 15px; /* Aggiunto margine inferiore qui */
    }
    th, td {
        padding: 10px;
        border: 1px solid #ddd;
    }
    th {
        background-color: #f2f2f2;
    }
    tr:nth-child(even) {
        background-color: #f9f9f9;
    }
    /* Stili per i link */
    a {
        color: #007bff;
        text-decoration: none;
    }
    a:hover {
        text-decoration: underline;
    }
</style>

</head>
<body>

<div class="container">
    <?php
    $macrogruppi = array();

    $macrogruppi = array(
      'Immobile' => array(
          'immobile' => array('Id', 'Nome', 'Posizione'),
          'affitto' => array('Id', 'Mese', 'Importo', 'CodImmobile'),
          'rifuiti' => array('id', 'Spesa', 'CodImmobile', 'Anno'),
          'manutenzione' => array('Id', 'Motivo', 'Data', 'Costo', 'CodImmobile'),
          'bolletta' => array('Id', 'Motivo', 'DataIns', 'Importo', 'percorso', 'Scadenza', 'Stato', 'Metodo', 'CodImmobile', 'mese1', 'mese2', 'DataPagamento')
      ),
      'Veicolo' => array(
          'veicolo' => array('id', 'Nome', 'Tipo'),
          'manutenzione1' => array('id', 'Tipo', 'CodVeicolo', 'Importo', 'Metodo', 'percorso'),
          'assicurazione' => array('Id', 'Tipo', 'Codveicolo', 'Importo', 'percorso', 'Scadenza', 'Stato', 'Metodo', 'DataPagamento'),
          'bollo' => array('Id', 'CodVeicolo', 'Importo', 'percorso', 'Scadenza', 'Stato', 'Metodo', 'DataPagamento'),
          'gestione' => array('id', 'Tipo', 'Importo', 'CodVeicolo'),
          'riparazioni' => array('id', 'Motivo', 'Importo', 'percorso', 'CodVeicolo', 'Metodo'),
          'viaggio' => array('id', 'Nome'),
          'viaggio_veicolo' => array('id', 'CodVeicolo', 'CodViaggio', 'Importo'),
          'spesa_viaggio' => array('id', 'CodViaggio', 'CodViaggio_veicolo', 'Motivo', 'Importo')
      )
    );
    // Genera i pulsanti per mostrare/nascondere tutte le tabelle per ogni macrogruppo
    foreach ($macrogruppi as $macrogruppo => $tabelle) {
      // Mostra il nome del macrogruppo
      echo '<h2>' . $macrogruppo . '</h2>';

      // Pulsante per mostrare/nascondere tutte le tabelle del macrogruppo
      echo '<button class="btn showAllTablesBtn" data-group="' . $macrogruppo . '">Mostra/Nascondi tutte le Tabelle</button>';

      // Genera i pulsanti per mostrare singolarmente le tabelle
      foreach ($tabelle as $nomeTabella => $colonne) {
          echo '<button class="btn showTableBtn" data-table="' . $nomeTabella . '">Mostra/Nascondi ' . $nomeTabella . '</button>';
          echo '<table class="data-table ' . $nomeTabella . ' ' . $macrogruppo . '" data-group="' . $macrogruppo . '" style="display:none;">';
          echo '<thead><tr>';
          foreach ($colonne as $colonna) {
              echo '<th>' . $colonna . '</th>';
          }
          echo '</tr></thead>';
          echo '<tbody>';

          // Esegui la query per ottenere i dati dalla tabella
          $sql = "SELECT * FROM " . $nomeTabella;
          $result = $conn->query($sql);

          if ($result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) {
                  echo '<tr>';
                  foreach ($colonne as $colonna) {
                      // Verifica se la colonna è "percorso" e genera il link per il download
                      if ($colonna === 'percorso') {
                            
                          
                            // Estrai il nome del file dal percorso completo
                            $percorsoCompleto = $row[$colonna];
                            $nomeFile = basename($percorsoCompleto);
                            $tmp = explode("_", $nomeFile);
                            // Crea un link per il download del file con il nome desiderato
                            echo '<td><a href="' . $percorsoCompleto . '" download="' . $tmp[1] . '">Download</a></td>';


                        } else {
                            echo '<td>' . $row[$colonna] . '</td>';
                        }

                  }
                  echo '</tr>';
              }
          } else {
              echo '<tr><td colspan="' . count($colonne) . '">0 risultati</td></tr>';
          }

          echo '</tbody></table>';
      }
  }
  ?>
</div>
<script>
    // Funzione per gestire il clic sui pulsanti per mostrare/nascondere le tabelle
    function toggleTable(tableName) {
        console.log("Toggling table:", tableName);
        const table = document.querySelector('.' + tableName);
        if (table) {
            if (table.style.display === 'none') {
                table.style.display = 'table';
            } else {
                table.style.display = 'none';
            }
        }
    }

    // Aggiungi un gestore di eventi per il clic sui pulsanti per mostrare/nascondere tutte le tabelle di un macrogruppo
    const showAllTablesBtns = document.querySelectorAll('.showAllTablesBtn');
    showAllTablesBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            const group = btn.getAttribute('data-group');
            const tables = document.querySelectorAll('.data-table[data-group="' + group + '"]');
            tables.forEach(function(table) {
                if (table.style.display === 'none') {
                    table.style.display = 'table';
                } else {
                    table.style.display = 'none';
                }
            });
        });
    });

    // Aggiungi un gestore di eventi per il clic sui pulsanti per mostrare singolarmente le tabelle
    const showTableBtns = document.querySelectorAll('.showTableBtn');
    showTableBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            const tableName = btn.getAttribute('data-table');
            console.log("Clicked button for table:", tableName);
            toggleTable(tableName);
        });
    });
</script>
</body>
</html>

