<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
  header('Location:../../login.php');
  die();
}
require '../../connection.php';
?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Example</title>
    <style>
    body {
        padding-top: 20px;
        font-family: Arial, sans-serif;
        padding: 20px;
    }
    h1 {
        text-align: center;
        margin-bottom: 20px;
    }
    form {
        max-width: 500px;
        margin: 0 auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .input-group {
        display: flex;
    }
    .input-group input {
        margin-right: 10px;
    }
    .button {
        display: block;
        width: 100%;
        padding: 10px;
        font-size: 16px;
        text-align: center;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        margin-top: 20px; /* Aggiunto margine superiore al pulsante */
    }
    .button:hover {
        background-color: #0056b3;
    }
    /* Aggiunto margine inferiore al secondo select */
    #categoria + .form-group {
        margin-bottom: 20px;
    }
</style>

    <!-- Collegamento al file CSS di Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script>
        function mostraCampi(opzione) {
            // Nascondi tutti gli input
            var inputs = document.querySelectorAll('.campo');
            for (var i = 0; i < inputs.length; i++) {
                inputs[i].style.display = 'none';
            }

            // Mostra gli input relativi all'opzione selezionata
            var opzioneSelezionata = document.getElementById(opzione);
            if (opzioneSelezionata) {
                opzioneSelezionata.style.display = 'block';
            }
        }
        function mostraCampi1(opzione) {
            // Nascondi tutti gli input
            var inputs = document.querySelectorAll('.campo1');
            for (var i = 0; i < inputs.length; i++) {
                inputs[i].style.display = 'none';
            }

            // Mostra gli input relativi all'opzione selezionata
            var opzioneSelezionata = document.getElementById(opzione);
            if (opzioneSelezionata) {
                opzioneSelezionata.style.display = 'block';
            }
        }
    </script>
</head>
<body>
    <form  name="dati" id="dati" action="ricezione.php" method="post" enctype="multipart/form-data">
        <div class="container"> <!-- Aggiunto container Bootstrap -->
            <label for="categoria">Seleziona una categoria:</label>
            <select id="categoria" class="form-control" onchange="mostraCampi(this.value)"> <!-- Aggiunto form-control Bootstrap -->
                <option value="">Seleziona...</option>
                <option value="immobiliare">Immobiliare</option>
                <option value="veicoli">Veicoli</option>
            </select>
            
            <div id="immobiliare" class="campo" style="display: none;">
                <label for="nome_immobile">Seleziona un immobile:</label>
                <select id="nome_immobile" name="immobile" class="form-control"> 
                    <option value="">Seleziona...</option>
                    <?php
                        $sql = "SELECT id, Nome FROM immobile";
                        $result = $conn->query($sql);
            
                        // Se ci sono risultati dalla query
                        if ($result->num_rows > 0) {
                            // Output delle opzioni come tag option nel select
                            while($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row['id'] . "'>" . $row['Nome'] ."</option>";
                            }
                        } else {
                            echo "<option value=''>Nessuna opzione disponibile</option>";
                        }
                    ?>
                </select>
                <label for="categoria">Seleziona il tipo di spesa:</label>
                <select id="categoria" class="form-control" name="categoria-tipo" onchange="mostraCampi1(this.value)"> <!-- Aggiunto form-control Bootstrap -->
                    <option value="">Seleziona...</option>
                    <option value="bolletta">bolletta</option>
                    <option value="manutenzione">manutenzione</option>
                    <option value="rifiuti">spesa rifiuti</option>
                </select>

                <div id="bolletta" class="campo1" style="display: none;">   

                    <label for="motivo">Tipo bolletta</label>
                    <select id="motivo" class="form-control" name="motivo" > 
                        <option value="">Seleziona...</option>
                        <option value="Gas">Gas</option>
                        <option value="Luce">Luce</option>
                        <option value="Acqua">Acqua</option>
                    </select>  
                    <label for="costo">Importo da pagare:</label>
                    <input type="number" name="bolletta-costo" class="form-control" min="0" step="0.01">

                    <div class="form-group">
                        <label for="scadenza">Mese della bolletta:</label>
                        <div class="input-group">
                            <input type="month" name="bolletta-mese1" class="form-control">
                            <input type="month" name="bolletta-mese2" class="form-control">
                        </div>
                    </div>

                    <label for="scadenza">Scadenza pagamento:</label>
                    <input type="date"  name="bolletta-scadenza" class="form-control">  

                    <label for="file">Fattura:</label>
                    <input type="file" name="bolletta-file" class="form-control">
                </div>

                <div id="manutenzione" class="campo1" style="display: none;">   
                    <label for="costo">Motivo:</label>
                    <input type="text"  name="manutenzione-motivo" class="form-control">
                    <label for="manutenzione">Giorno manutenzione:</label>
                    <input type="date"  name="manutenzione-eseguita" class="form-control">  
                    <label for="costo">Spesa:</label>
                    <input type="number" name="manutenzione-costo" class="form-control" min="0" step="0.01"> 
                </div>
                <div id="rifiuti" class="campo1" style="display: none;">     
                    <label for="rifiuti">Spesa rifiuti:</label>
                    <input type="number" name="rifiuti-costo" class="form-control" min="0" step="0.01">
                    <label for="anno">Inserisci l'anno:</label>
                    <input type="number" id="anno" name="rifiuti-anno" class="form-control"  min="2000" max="3000" step="1">
                </div>
            </div>
            
            <div id="veicoli" class="campo" style="display: none;">
                <label for="nome_veicolo">Seleziona un veicolo:</label>
                <select id="nome_veicolo" name="veicolo" class="form-control"> 
                    <option value="">Seleziona...</option>
                    <?php
                        $sql = "SELECT id, Nome, Tipo FROM veicolo";
                        $result = $conn->query($sql);
            
                        // Se ci sono risultati dalla query
                        if ($result->num_rows > 0) {
                            // Output delle opzioni come tag option nel select
                            while($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row['id'] . "'>" . $row['Nome'] . "-" . $row['Tipo'] . "</option>";
                            }
                        } else {
                            echo "<option value=''>Nessuna opzione disponibile</option>";
                        }
                    ?>
                </select>   
                <label for="categoria">Seleziona il tipo di spesa:</label>
                <select id="categoria" class="form-control" name="tipo" onchange="mostraCampi1(this.value)"> <!-- Aggiunto form-control Bootstrap -->
                    <option value="">Seleziona...</option>
                    <option value="assicurazione">Assicurazione</option>
                    <option value="bollo">Bollo</option>
                    <option value="riparazione">Riparazione</option>
                    <option value="manutenzione1">Manutenzione</option>
                    <option value="gestione">Costi gestione</option>
                </select>
                
                <div id="assicurazione" class="campo1" style="display: none;">
                    <label for="costo">Tipo:</label>
                    <input type="text" name="assicurazione-tipo" class="form-control">
                    <label for="costo">Spesa:</label>
                    <input type="number" name="assicurazione-costo" class="form-control" min="0" step="0.01">
                    <label for="scadenza">Scadenza:</label>
                    <input type="date"  name="assicurazione-scadenza" class="form-control">  
                    <label for="file">Fattura:</label>
                    <input type="file" name="assicurazione-file" class="form-control">
                </div>

                <div id="bollo" class="campo1" style="display: none;">
                    <label for="metodo">Spesa:</label>
                    <input type="text"  name="bollo-costo" class="form-control"> 
                    <label for="scadenza">Scadenza:</label>
                    <input type="date"  name="bollo-scadenza" class="form-control">
                    <label for="file">Fattura:</label>
                    <input type="file" name="bollo-file" class="form-control">
                </div>
                <div id="riparazione" class="campo1" style="display: none;">
                    <label for="motivo">Motivo:</label>
                    <input type="text"  name="riparazione-motivo" class="form-control">   
                    <label for="costo">Spesa:</label>
                    <input type="number" name="riparazione-costo" class="form-control" min="0" step="0.01"> 
                    <label for="costo">Metodo pagamento:</label>
                    <input type="text" name="riparazione-metodo" class="form-control"> 
                    <label for="file">Fattura:</label>
                    <input type="file" name="riparazione-file" class="form-control">
                </div>
                <div id="manutenzione1" class="campo1" style="display: none;">
                    <label for="motivo">Motivo:</label>
                    <input type="text"  name="manutenzione1-motivo" class="form-control">   
                    <label for="costo">Spesa:</label>
                    <input type="number" name="manutenzione1-costo" class="form-control" min="0" step="0.01"> 
                    <label for="costo">Metodo pagamento:</label>
                    <input type="text" name="manutenzione1-metodo" class="form-control"> 
                    <label for="file">Fattura:</label>
                    <input type="file" name="manutenzione1-file" class="form-control">
                </div>
                <div id="gestione" class="campo1" style="display: none;">
                    <label for="categoria">Seleziona il tipo di spesa per la gestione:</label>
                    <select id="categoria" class="form-control" name="gestione-tipo">
                        <option value="">Seleziona...</option>
                        <option value="benzina">Benzina</option>
                        <option value="lavaggio">Lavaggio</option>
                        <option value="pedaggio">Pedaggio</option>
                        <option value="parcheggio">Parcheggio</option>
                    </select>
                    <label for="costo">Spesa:</label>
                    <input type="number" name="gestione-costo" class="form-control" min="0" step="0.01"> 
                </div>


            </div>
        </div>

        <input class="button" type="submit" value="Invia">
    </form>
</body>
</html>

