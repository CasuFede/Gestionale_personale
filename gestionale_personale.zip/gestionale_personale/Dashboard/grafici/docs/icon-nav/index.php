<?php
session_start();
require '../../../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../../../login.php');
    die();
}
require '../../../../connection.php';
?>  


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">

    <title>
      
        Icon nav &middot; 
      
    </title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns"></script> <!-- Includiamo l'adattatore per le date -->
  
    <link href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700,400italic" rel="stylesheet">
    
      <link href="../assets/css/toolkit-inverse.css" rel="stylesheet">
    
    
    <link href="../assets/css/application.css" rel="stylesheet">

    <style>
      /* note: this is a hack for ios iframe for bootstrap themes shopify page */
      /* this chunk of css is not part of the toolkit :) */
      body {
        width: 1px;
        min-width: 100%;
        width: 100%;
      }
      #centro {
        justify-content: center;
        align-items: center;
        
      }
/* Stili per il form */
form {
    margin: 20px;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

/* Stili per il label */
label {
    margin-bottom: 10px;
    display: block;
}

/* Stili per il select */
select {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border-radius: 5px;
    border: 1px solid #ccc;
    margin-bottom: 10px;
}

/* Stili per il button */
.button {
    padding: 10px 20px;
    font-size: 16px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    display: inline-block; /* Imposta il display inline-block */
    margin-right: 10px; /* Aggiunge un margine destro per separare i pulsanti */
}

.button:last-child {
    margin-right: 0; /* Rimuove il margine destro all'ultimo pulsante per evitare spazi vuoti */
}

.button:hover {
    background-color: #0056b3;
}


    </style>
  </head>


<body>
<?php

  /*----------------------------------------------------------*/
  //spese per categoria di ogni immobile in base a 2 mesi
  // Data di inizio dell'intervallo (esempio: oggi)

  //guadagni all'ora
  $sql = "SELECT 
  i.Nome AS NomeImmobile,
  COALESCE(SUM(b.Importo / 2), 0) AS SpesaBollette,
  COALESCE(SUM(m.Costo), 0) AS SpesaManutenzioni,
  COALESCE(r.Spesa, 0) AS SpesaRifiuti,
  COALESCE(SUM(b.Importo / 2), 0) + COALESCE(SUM(m.Costo), 0) + COALESCE(r.Spesa, 0) AS SpesaTotale
FROM 
  immobile i
LEFT JOIN 
  bolletta b ON i.Id = b.CodImmobile AND (YEAR('2024-01-01') = YEAR(b.mese1) AND MONTH('2024-01-01') = MONTH(b.mese1) OR YEAR('2024-01-01') = YEAR(b.mese2) AND MONTH('2024-01-01') = MONTH(b.mese2))
LEFT JOIN 
  manutenzione m ON i.Id = m.CodImmobile AND YEAR('2024-01-01') = YEAR(m.Data) AND MONTH('2024-01-01') = MONTH(m.Data)
LEFT JOIN 
  rifuiti r ON i.Id = r.CodImmobile AND YEAR('2024-01-01') = r.Anno
GROUP BY 
  i.Nome;
";
      $i = 0;
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    
  while ($row = mysqli_fetch_assoc($result)) {
      $array[$i]['Nome'] = $row["NomeImmobile"];
      $array[$i]['bollette'] = $row["SpesaBollette"];
      $array[$i]['manutenzioni'] = $row["SpesaManutenzioni"];
      $array[$i]['rifuiti'] = $row["SpesaRifiuti"];
      $array[$i]['totale'] = $row["SpesaTotale"];
      $i++;
  }
  } else{
    echo "non ci sono risultati";
  }
  //print_r($array);
  $i = 0;
  //affitto per immobile e in base al mese
  $sql = "
  SELECT 
  i.Nome AS NomeImmobile,
  CASE 
      WHEN a.Mese IS NULL THEN 0
      ELSE a.Importo 
  END AS ImportoAffitto,
  a.Mese AS MeseAffitto
FROM 
  immobile i
LEFT JOIN 
  affitto a ON a.CodImmobile = i.Id
         AND YEAR(a.Mese) = YEAR('2024-01-01') 
         AND MONTH(a.Mese) = MONTH('2024-01-01')
         ORDER BY i.Nome;";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
          $array1[$i]['Nome'] = $row["NomeImmobile"];
          $array1[$i]['Affitto'] = $row["ImportoAffitto"];
          $array1[$i]['Mese'] = $row["MeseAffitto"];
          $i++;
        } 
        } else{
          echo "non ci sono risultati";
        }
        
//in un anno i 12 mesi suddivisa per tipo i costi
//in un anno i 12 mesi suddivisa per tipo i costi
// Query SQL
$nome_immobile = 3;
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['nome-immobile'])) {
  $nome_immobile = $_POST['nome-immobile'];
} else {
  $nome_immobile = 3;
}
$sql = "SELECT
immobile.Nome,
bolletta.Motivo,
bolletta.Importo,
bolletta.Mese1,
bolletta.Mese2
FROM
bolletta
INNER JOIN
immobile ON bolletta.CodImmobile = immobile.Id
WHERE
CodImmobile = '$nome_immobile'
ORDER BY
bolletta.Motivo, bolletta.Mese1;";
      $mesi = [
        '01' => 'Gennaio',
        '02' => 'Febbraio',
        '03' => 'Marzo',
        '04' => 'Aprile',
        '05' => 'Maggio',
        '06' => 'Giugno',
        '07' => 'Luglio',
        '08' => 'Agosto',
        '09' => 'Settembre',
        '10' => 'Ottobre',
        '11' => 'Novembre',
        '12' => 'Dicembre'
    ];
    
    $result = $conn->query($sql);
    // Array per memorizzare i dati aggregati per periodo mensile
    $monthlyData = [];

   // Ciclo sui risultati della query e aggregazione dei dati per periodo mensile
while ($row = mysqli_fetch_assoc($result)) {
  $nome = $row["Nome"];
  $mese1 = explode("-", $row["Mese1"]);
  $mese2 = explode("-", $row["Mese2"]);
  $importo = $row["Importo"];
  
  // Calcola il periodo mensile (es. gennaio-febbraio, marzo-aprile, ecc.)
  $monthPeriod = $mesi[$mese1[1]] . "-" . $mesi[$mese2[1]];

  // Aggiungi l'importo al periodo mensile corrispondente e al tipo di bolletta
  if (isset($monthlyData[$monthPeriod][$row["Motivo"]])) {
      $monthlyData[$monthPeriod][$row["Motivo"]] += $importo;
  } else {
      $monthlyData[$monthPeriod][$row["Motivo"]] = $importo;
  }
}
    // Prepara i dati per il grafico

// Prepara i dati normalizzati per il grafico
$chartData = [];   // Array per i dati delle colonne

foreach ($monthlyData as $monthPeriod => $data) {
  $chartData[$monthPeriod] = [
    'Gas' => isset($data['Gas']) ? intval($data['Gas']) : 0,
    'Luce' => isset($data['Luce']) ? intval($data['Luce']) : 0,
    'Acqua' => isset($data['Acqua']) ? intval($data['Acqua']) : 0
];

}

// Definisci le etichette mensili basate sulle chiavi dell'array $chartData
$chartLabels = array_keys($chartData);

/*echo "Labels: ";
print_r($chartLabels);

echo "Data: ";
print_r($chartData);*/

$sql = "SELECT COALESCE(m.id, 'Valore di default per Id') AS id,
COALESCE(m.Motivo, 'Nessuno') AS Motivo,
COALESCE(m.Data, '0000-00-00') AS Data,
COALESCE(m.Costo, '0') AS Costo,
COALESCE(m.CodImmobile, 'Valore di default per CodImmobile') AS CodImmobile,
COALESCE(i.Nome, 'Valore di default per NomeImmobile') AS NomeImmobile,
COALESCE(i.Posizione, 'Valore di default per Posizione') AS Posizione
FROM immobile AS i
LEFT JOIN manutenzione AS m ON m.CodImmobile = i.Id
WHERE YEAR(COALESCE(m.Data, NOW())) = '2024' AND i.Id = '$nome_immobile'
ORDER BY COALESCE(m.Data, NOW())
LIMIT 0, 25;";

$result = $conn->query($sql);
$i = 0;
// Verifica se ci sono risultati
if ($result->num_rows > 0) {
    // Iterazione sui risultati
    while ($row = $result->fetch_assoc()) {
        // Output dei dati
        /*echo "ID: " . $row["Id"] . " - Motivo: " . $row["Motivo"] . " - Data: " . $row["Data"] . "<br>";
        echo "Nome Immobile: " . $row["NomeImmobile"] . " - Posizione: " . $row["Posizione"] . "<br>";*/
        //$manutenzione['Nome'] = $row["NomeImmobile"];
        $manutenzione[$i]['Data'] = $row["Data"];
        $manutenzione[$i]['Motivo'] = $row["Motivo"];
        $manutenzione[$i]['Costo'] = $row["Costo"];
      $i++;
    }
    //echo "fwegherwiugerikghkrewihgiuerhghwreuihgilewrglhweiurghileuggu: " . count($manutenzione);
} else {
    echo "Nessun risultato trovato.";
}
?>



<div class="with-iconav">

  <nav class="iconav">
    
    <div class="iconav-slider">
      <ul class="nav nav-pills iconav-nav flex-md-column">
        
        <li class="nav-item">
          <a class="nav-link " href="../../../grafici.php" title="Indietro" data-toggle="tooltip" data-placement="right" data-container="body">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-in-left" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M10 3.5a.5.5 0 0 0-.5-.5h-8a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h8a.5.5 0 0 0 .5-.5v-2a.5.5 0 0 1 1 0v2A1.5 1.5 0 0 1 9.5 14h-8A1.5 1.5 0 0 1 0 12.5v-9A1.5 1.5 0 0 1 1.5 2h8A1.5 1.5 0 0 1 11 3.5v2a.5.5 0 0 1-1 0z"/>
  <path fill-rule="evenodd" d="M4.146 8.354a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H14.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708z"/>
</svg>
            <small class="iconav-nav-label hidden-md-up">Indietro</small>
          </a>
        </li>
        
      </ul>
    </div>
  </nav>

  <div class="container">
    <div class="dashhead">
      <div class="dashhead-titles">
        <h6 class="dashhead-subtitle">Grafici</h6>
        <h3 class="dashhead-title">Panoramica</h3>
      </div>

      <div class="dashhead-toolbar">
        <div class="btn-group dashhead-toolbar-item btn-group-thirds">
          <input type="date" class="form-control" >
        </div>
        <div class="btn-group dashhead-toolbar-item btn-group-thirds">
          <input type="date" class="form-control">
        </div>
      </div>
    </div>



    <ul class="nav nav-bordered mt-4 mt-md-2 mb-0 clearfix" role="tablist">
      <li class="nav-item" role="presentation">
        <a href="#immobile" class="nav-link active" role="tab" data-toggle="tab" aria-controls="traffic">Spesa-Profitto</a>
      </li>
      <li class="nav-item" role="presentation">
        <a href="#sales" class="nav-link" role="tab" data-toggle="tab" aria-controls="sales">Manutenzioni</a>
      </li>
      <li class="nav-item" role="presentation">
        <a href="#support" class="nav-link" role="tab" data-toggle="tab" aria-controls="support">Bollette</a>
      </li>
    </ul>




    <hr class="mt-0 mb-5">

    <div class="tab-content">
      <div role="tabpanel" class="tab-pane active" id="immobile">
          <div class="row text-center m-t-md">
          <?php for ($i = 0; $i < count($array); $i++) {
            ?>
            <div class="col-md-4 mb-5">
                <div class="w-3 mx-auto">
                  <canvas
                    class="ex-graph"
                    width="200" height="200"
                    data-chart="doughnut"
                    data-dataset="[<?php echo $array[$i]['totale'];?>, <?php echo $array1[$i]['Affitto'];?>]"
                    data-dataset-options="{ borderColor: '#252830', backgroundColor: ['#FF0000', '#1bc98e'] }"
                    data-labels="['Spese', 'Affitto']"
                    >
                  </canvas>
                </div>
                <strong class="text-muted"></strong>
                <h4><?php echo $array[$i]['Nome'];?></h4>
              </div>
              <?php }?>
          
            </div>
        </div>

      <div role="tabpanel" class="tab-pane" id="sales">
        <div class="ex-line-graphs mb-5">
        <canvas id="myChart123" width="400" height="100"></canvas>
        <form name="dati" action="index.php" method="post">
          <label for="nome_immobile">Seleziona un immobile:</label>
            <select id="nome_immobile" name="nome-immobile" class="form-control"> 
                <option value="">Seleziona...</option>
                <?php
                $sql = "SELECT id, Nome FROM immobile";
                $result = $conn->query($sql);

                // Se ci sono risultati dalla query
                if ($result->num_rows > 0) {
                    // Output delle opzioni come tag option nel select
                    while($row = $result->fetch_assoc()) {
                        $selected = "";
                        if(isset($_POST['nome-immobile']) && $_POST['nome-immobile'] == $row['id']) {
                            $selected = "selected";
                        }
                        echo "<option value='" . $row['id'] . "' $selected>" . $row['Nome'] ."</option>";
                    }
                } else {
                    echo "<option value=''>Nessuna opzione disponibile</option>";
                }
                ?>
            </select>

                <input class="button" type="submit" value="Invia" >    
        </form>       
        </div>
        
      </div>
      <div role="tabpanel" class="tab-pane" id="support">    
        <div class="ex-line-graphs mb-5">
            <canvas
                class="ex-line-graph"
                width="600" height="400"
                data-chart="bar"
                data-dark="true"
                data-labels="[<?php echo "'" . implode("','", $chartLabels) . "'"; ?>]"
                data-dataset="[
                    [<?php foreach ($chartData as $monthData) { echo $monthData['Gas'] . ','; } ?>],
                    [<?php foreach ($chartData as $monthData) { echo $monthData['Luce'] . ','; } ?>],
                    [<?php foreach ($chartData as $monthData) { echo $monthData['Acqua'] . ','; } ?>]
                ]"
                data-dataset-options="[{label: 'Gas'}, {label: 'Luce'}, {label: 'Acqua'}]"> <!-- Adjusted y-axis options -->
                  
              </canvas>
          </div>
          <form name="dati" action="index.php" method="post">
          <label for="nome_immobile">Seleziona un immobile:</label>
          
            <select id="nome_immobile" name="nome-immobile" class="form-control"> 
                <option value="">Seleziona...</option>
                <?php
                $sql = "SELECT id, Nome FROM immobile";
                $result = $conn->query($sql);

                // Se ci sono risultati dalla query
                if ($result->num_rows > 0) {
                    // Output delle opzioni come tag option nel select
                    while($row = $result->fetch_assoc()) {
                        $selected = "";
                        if(isset($_POST['nome-immobile']) && $_POST['nome-immobile'] == $row['id']) {
                            $selected = "selected";
                        }
                        echo "<option value='" . $row['id'] . "' $selected>" . $row['Nome'] ."</option>";
                    }
                } else {
                    echo "<option value=''>Nessuna opzione disponibile</option>";
                }
                ?>
            </select>

                <input class="button" type="submit" value="Invia">    
        </form>       
      </div>
      
    </div>

    <div class="hr-divider my-4">
      <h3 class="hr-divider-content hr-divider-heading">Quick stats</h3>
    </div>

    <div class="row statcards mt-3 mb-3 text-xs-center text-md-left">
      <div class="col-6 col-md-3 statcard mb-4">
        <h3 class="statcard-number text-success">
          12,938
          <small class="delta-indicator delta-positive">5%</small>
        </h3>
        <span class="statcard-desc">Page views</span>
      </div>
      <div class="col-6 col-md-3 statcard mb-4">
        <h3 class="statcard-number text-danger">
          758
          <small class="delta-indicator delta-negative">1.3%</small>
        </h3>
        <span class="statcard-desc">Downloads</span>
      </div>
      <div class="col-6 col-md-3 statcard mb-4">
        <h3 class="statcard-number text-success">
          1,293
          <small class="delta-indicator delta-positive">6.75%</small>
        </h3>
        <span class="statcard-desc">Sign-ups</span>
      </div>
      <div class="col-6 col-md-3 statcard mb-4">
        <h3 class="statcard-number text-danger">
          758
          <small class="delta-indicator delta-negative">1.3%</small>
        </h3>
        <span class="statcard-desc">Downloads</span>
      </div>
    </div>

    <hr class="my-4">

   

  </div>
</div>
<script>
  var ctx = document.getElementById('myChart123').getContext('2d');
  var myChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: [<?php
        for ($i = 0; $i < count($manutenzione); $i++){
          echo "'" . $manutenzione[$i]['Data'] . "'" . ",";
        }
      ?>],
      datasets: [{
        label: 'Manutenzione',
        data: [
          <?php
            for ($i = 0; $i < count($manutenzione); $i++){
              echo "{ x: '" . $manutenzione[$i]['Data'] . "', y: " . $manutenzione[$i]['Costo'] . ", motivo: '" . $manutenzione[$i]['Motivo'] . "' },";
            }
          ?>
        ],
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1,
        pointBackgroundColor: 'rgba(255, 99, 132, 1)',
        pointRadius: 5,
        pointHoverRadius: 7
      }]
    },
    options: {
      scales: {
        x: {
          time: {
            unit: 'day',
            parser: 'yyyy-MM-dd'
          }
        },
        y: {
          ticks: {
            stepSize: 100
          }
        }
      },
      plugins: {
        tooltip: {
          callbacks: {
            label: function(context) {
              var label = context.dataset.label || '';
              if (label) {
                label += ': ';
              }
              if (context.parsed.y !== null) {
                label += context.parsed.y + ' - ' + context.dataset.data[context.dataIndex].motivo;
              }
              return label;
            }
          }
        }
      }
    }
  });
</script>


    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/tether.min.js"></script>
    <script src="../assets/js/chart.js"></script>
    <script src="../assets/js/tablesorter.min.js"></script>
    <script src="../assets/js/toolkit.js"></script>
    <script src="../assets/js/application.js"></script>
    <script>
      // execute/clear BS loaders for docs
      $(function(){while(window.BS&&window.BS.loader&&window.BS.loader.length){(window.BS.loader.pop())()}})
    </script>
  </body>
</html>

