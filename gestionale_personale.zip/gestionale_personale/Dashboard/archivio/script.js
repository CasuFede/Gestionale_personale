$(document).ready(function() {
    // Carica i documenti dal server
    $.ajax({
        url: 'get_documents.php',
        type: 'GET',
        dataType: 'json',
        success: function(data) {
            const documentsList = $('#documentsList');

            // Raggruppa i documenti per gerarchia e categoria
            const gerarchie = {};
            Object.keys(data).forEach(gerarchia => {
                gerarchie[gerarchia] = {};

                // Se il valore è un array, potrebbe essere una categoria con o senza sottocategorie
                if (Array.isArray(data[gerarchia])) {
                    data[gerarchia].forEach(documento => {
                        const categoria = documento.Categoria.split('/');
                        const categoriaPrincipale = categoria[0];
                        const sottocategoria = categoria[1] || null;

                        // Assicuriamoci che la struttura sia sempre coerente, anche se non ci sono sottocategorie
                        if (!gerarchie[gerarchia][categoriaPrincipale]) {
                            gerarchie[gerarchia][categoriaPrincipale] = [];
                        }

                        gerarchie[gerarchia][categoriaPrincipale].push({
                            nome: sottocategoria,
                            documenti: [documento]  // Mettiamo sempre il documento in un array
                        });
                    });
                } else {
                    // Se il valore è un oggetto, trasformalo in un array di oggetti
                    const categoriaPrincipale = gerarchia;
                    const categoria = data[gerarchia];

                    if (!gerarchie[gerarchia][categoriaPrincipale]) {
                        gerarchie[gerarchia][categoriaPrincipale] = [];
                    }

                    Object.keys(categoria).forEach(subCategoria => {
                        if (Array.isArray(categoria[subCategoria])) {
                            // Se la sottocategoria è già un array, aggiungila direttamente
                            gerarchie[gerarchia][categoriaPrincipale].push({
                                nome: subCategoria,
                                documenti: categoria[subCategoria]
                            });
                        } else {
                            // Se la sottocategoria non è un array, trasformala in un array di oggetti
                            gerarchie[gerarchia][categoriaPrincipale].push({
                                nome: subCategoria,
                                documenti: [categoria[subCategoria]]
                            });
                        }
                    });
                }
            });

            // Aggiungi le gerarchie al documento HTML
            Object.keys(gerarchie).forEach(gerarchia => {
                const gerarchiaContainer = $('<div class="gerarchia-container"></div>');
                gerarchiaContainer.append('<h2>' + gerarchia + '</h2>');

                const gerarchiaCategories = gerarchie[gerarchia];
                Object.keys(gerarchiaCategories).forEach(categoriaPrincipale => {
                    const categoriaContainer = $('<div class="categoria-container"></div>');
                    //categoriaContainer.append('<h3>' + categoriaPrincipale + '</h3>');

                    const categoriaDocuments = gerarchiaCategories[categoriaPrincipale];
                    categoriaDocuments.forEach(categoria => {
                        if (categoria.nome !== null) {
                            // Se la sottocategoria non corrisponde al nome della categoria principale,
                            // aggiungi il nome della sottocategoria come titolo
                            var espressioneRegolare = /\d/;

                            if (!espressioneRegolare.test(categoria.nome)) {
                                categoriaContainer.append('<h4>' + categoria.nome + '</h4>');
                            }
                        }

                        const documentList = $('<div class="document-list" ></div>');
                        categoria.documenti.forEach(documento => {
                            const documentItem = $('<div class="document-item"></div>');
                            documentItem.append('<p>' + documento.Nome + '</p>');
                            documentItem.append('<p>' + documento.Motivazione + '</p>');
                            documentItem.append('<a href="preview.php?file=' + documento.Id + '" target="_blank">Visualizza Anteprima</a>');
                            documentItem.append('<a href="download.php?file=' + documento.Id + '">Scarica</a>');

                            documentList.append(documentItem);
                        });
                        categoriaContainer.append(documentList);
                    });

                    gerarchiaContainer.append(categoriaContainer);
                });

                documentsList.append(gerarchiaContainer);
            });
        },
        error: function(xhr, status, error) {
            console.error('Errore nel caricamento dei documenti:', error);
        }
    });

    // Carica l'anteprima del file selezionato dall'utente
    $('#file').on('change', function() {
        var file = this.files[0];
        var reader = new FileReader();

        reader.onload = function(e) {
            var preview = $('#preview');
            preview.html('<embed src="' + e.target.result + '" width="500" height="600"/>');
        };

        reader.readAsDataURL(file);
    });
});
