<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';

if(isset($_GET['file'])) {
    $fileId = $_GET['file'];
    
    $query = "SELECT percorso FROM documenti WHERE Id = $fileId";
    $result = $conn->query($query);

    if(mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $filePath = $row['percorso'];

        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="' . basename($filePath) . '"');
        header('Content-Length: ' . filesize($filePath));

        readfile($filePath);
        exit;
    } else {
        echo "Documento non trovato.";
    }
}
?>
