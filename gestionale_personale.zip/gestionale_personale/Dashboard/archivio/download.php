<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';

if(isset($_GET['file'])) {
    $fileId = $_GET['file'];
    
    $query = "SELECT percorso FROM documenti WHERE Id = $fileId";
    $result = $conn->query($query);

    if($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $filePath = $row['percorso'];

        $tmp = explode("_", $filePath);

        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . basename($tmp[1]) . '"');
        header('Content-Length: ' . filesize($filePath));

        readfile($filePath);
        exit;
    } else {
        echo "Documento non trovato.";
    }
}
?>
