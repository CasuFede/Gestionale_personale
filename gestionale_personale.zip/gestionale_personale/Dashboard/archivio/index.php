<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archivio Documenti</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        #preview {
            margin-top: 20px;
        }
        embed {
            width: 100%;
            height: 600px;
        }
    </style>
</head>
<body>
    <h1>Archivio Documenti</h1>
    <form id="uploadForm" action="upload.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="file">File</label>
            <input type="file" class="form-control-file" id="file" name="file">
        </div>
        <div class="form-group">
            <label for="nome">Nome</label>
            <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome">
        </div>
        <div class="form-group">
            <label for="motivazione">Motivazione</label>
            <input type="text" class="form-control" id="motivazione" name="motivazione" placeholder="Motivazione">
        </div>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="nome_veicolo">Seleziona una categoria:</label>
                <select id="nome_veicolo" name="categoria" class="form-control"> 
                    <option value="">Seleziona...</option>
                    <?php
                        $sql = "SELECT Id, Nome FROM categoria";
                        $result = $conn->query($sql);
            
                        // Se ci sono risultati dalla query
                        if ($result->num_rows > 0) {
                            // Output delle opzioni come tag option nel select
                            while($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row['Id'] . "'>" . $row['Nome'] . "</option>";
                            }
                        } else {
                            echo "<option value=''>Nessuna opzione disponibile</option>";
                        }
                    ?>
                </select> 
            </div>
            <div class="form-group col-md-6">
                <label for="nuova_categoria">Nuova categoria</label>
                <input type="text" class="form-control" id="nuova_categoria" name="nuova_categoria" >
            </div>
        </div>
        
        <button type="submit" class="btn btn-primary">Carica Documento</button>
    </form>
    <!-- <div id="documentsList"></div> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="script.js"></script>
</body>
</html>
