<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';

if(isset($_FILES['file'])) {
    $file = $_FILES['file'];
    $nome = $_POST['nome'];
    $motivazione = $_POST['motivazione'];
    $categoria = trim($_POST['categoria']);
    echo "ciao: "  . $categoria;
    $nuova_categoria = trim($_POST['nuova_categoria']);
    echo "ciao: "  . $nuova_categoria;

    if ($_FILES["file"]["error"] == UPLOAD_ERR_OK) {
        // Percorso della cartella in cui salvare il file
        $uploadDirectory = "documenti/";
    
        // Crea la cartella se non esiste
        if (!file_exists($uploadDirectory)) {
            mkdir($uploadDirectory, 0777, true);
        }
    
        // Nome del file
        $nomeFileOriginale = $_FILES["file"]["name"];
        $nomeFileTemporaneo = $_FILES["file"]["tmp_name"];
        
        // Rinomina il file in modo univoco
        $nomeFileUnico = uniqid() . '_' . $nomeFileOriginale;
        $nomeFileDestinazione = $uploadDirectory . $nomeFileUnico;
    
        // Salva il file rinominato direttamente nel percorso di destinazione
        if (move_uploaded_file($nomeFileTemporaneo, $nomeFileDestinazione)) {
            // Controlla se è stato passato un valore tramite POST
            if($_POST['nuova_categoria'] != "") {
                $nuova_categoria = $_POST['nuova_categoria'];
                $sql = "INSERT INTO categoria (Nome) VALUES ('$nuova_categoria ')";
                if ($conn->query($sql) === TRUE) {
                    $last_id = $conn->insert_id;
                    $sql = "INSERT INTO documenti (Nome, Motivazione, percorso, Categoria) VALUES ('$nome', '$motivazione', '$nomeFileDestinazione', '$last_id')";

                    if ($conn->query($sql) === TRUE) {
                        header("Location: index.php?uploadsuccess");
                        die();
                    } else {
                        header("Location: index.php?uploadfailure");
                        die();
                    }
                } else {
                    header("Location: index.php?uploadfailure");
                    die();
                }
            } else {
                $nuova_categoria = "";
                $sql = "INSERT INTO documenti (Nome, Motivazione, percorso, Categoria) VALUES ('$nome', '$motivazione', '$nomeFileDestinazione', '$categoria')";

                if ($conn->query($sql) === TRUE) {
                    header("Location: index.php?uploadsuccess");
                    die();
                } else {
                    header("Location: index.php?uploadfailure");
                    die();
                }
            }
            
        } else {
            echo "Si è verificato un errore durante il caricamento del file.";
        }
    } else {
        echo "Si è verificato un errore durante l'upload del file.";
    }

    

    
} else {
    header("Location: index.php?uploadfailure");
}
?>
