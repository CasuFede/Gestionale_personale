<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';

$sql = "SELECT documenti.Id, documenti.Nome, documenti.Motivazione, documenti.percorso, categoria.Nome AS Categoria FROM documenti INNER JOIN categoria ON categoria.Id = documenti.Categoria";
$result = $conn->query($sql);

$documentsByCategory = [];

while($row = $result->fetch_assoc()) {
    $categoria = $row['Categoria'];

    // Split della categoria in caso di sottocategorie
    $parts = explode('/', $categoria);
    $categoriaPrincipale = trim($parts[0]);
    $sottocategoria = isset($parts[1]) ? $parts[1] : null;

    // Aggiunta del documento alla categoria principale
    if (!isset($documentsByCategory[$categoriaPrincipale])) {
        $documentsByCategory[$categoriaPrincipale] = [];
    }

    // Aggiunta del documento alla sottocategoria, se presente
    if ($sottocategoria) {
        if (!isset($documentsByCategory[$categoriaPrincipale][$sottocategoria])) {
            $documentsByCategory[$categoriaPrincipale][$sottocategoria] = [];
        }
        $documentsByCategory[$categoriaPrincipale][$sottocategoria][] = $row;
    } else {
        $documentsByCategory[$categoriaPrincipale][] = $row;
    }
}
/*echo "<pre>";
print_r($documentsByCategory);
echo "</pre>";*/
echo json_encode($documentsByCategory);
?>
