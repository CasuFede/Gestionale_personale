<?php
session_start();
require '../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../login.php');
    die();
}
require '../connection.php';
?> 
<!DOCTYPE html>
<html>
    <head>
        <title>Ricezione dati</title>
        <meta charset="UTF-8" />
    </head>
    <body>
         
        <h1>Ricezione dati</h1>
        <?php
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            /*echo "Nome-imm: " . $_POST["nome-immobile"];
            echo "<br />";
            echo "Tipo-imm: " . $_POST["tipo-immobile"];
            echo "<br />";
            echo "pos-imm: " . $_POST["posizione-immobile"];
            echo "<br />";
            echo "Nome-veic: " . $_POST["nome-veicolo"];
            echo "<br />";
            echo "Tipo-veic: " . $_POST["tipo-veicolo"];
            echo "<br />";*/
            if (empty($_POST["tipo-veicolo"]) && empty($_POST["nome-veicolo"])) {
                if (empty($_POST["tipo-immobile"]) && empty($_POST["nome-immobile"]) && empty($_POST["posizione-immobile"])) {
                    if (empty($_POST["nome-viaggio"]) && empty($_POST["veicolo-viaggio"]) && empty($_POST["costo-veicolo-viaggio"]) && empty($_POST["costo-alloggio-viaggio"]) && empty($_POST["costo-cibo-viaggio"]) && empty($_POST["costo-volo-viaggio"]) && empty($_POST["costo-intrattenimento-viaggio"])) {
                        if (empty($_POST["affitto-immobile"]) && empty($_POST["importo-immobile"]) && empty($_POST["affitto-mese"])) {
                            $_SESSION['message1'] = "Errore nessun dato è stato inserito";
                            header('Location:invio.php');
                            die();
                        } else {
                            $nome_immobile1 = $_POST["affitto-immobile"];
                            $immporto_immobile = $_POST["importo-immobile"];
                            $mese = $_POST["affitto-mese"];
                            $mese = $mese . "-01";
                            $query = "INSERT INTO affitto (Mese, Importo, CodImmobile)
                            VALUES ('$mese', '$immporto_immobile', '$nome_immobile1')";
                            if($conn->query($query) === TRUE){
                                header('Location:invio.php');
                                $_SESSION['message1'] = "Affitto inserito con successo";
                                die();
                            }else{
                                $_SESSION['message1'] = "Inserimento affitto errore" . $conn->error;
                            }
                        }
                        
                    } else {
                        $nome_viaggio = $_POST["nome-viaggio"];

                        $veicolo_viaggio = $_POST["veicolo-viaggio"];
                        $costo_veicolo = $_POST["costo-veicolo-viaggio"];

                        $costo_alloggio = $_POST["costo-alloggio-viaggio"];
                        $costo_cibo = $_POST["costo-cibo-viaggio"];
                        $costo_volo = $_POST["costo-volo-viaggio"];
                        $costo_intrattenimento = $_POST["costo-intrattenimento-viaggio"];
                        
                        

                        $sql = "INSERT INTO viaggio (Nome) VALUES ('$nome_viaggio')";
                        if ($conn->query($sql) === TRUE) {
                            $last_id = $conn->insert_id; // Ottieni l'ID appena generato
                        } else {
                            $_SESSION['message1'] = "Errore nell'inserimento nella tabella2: " . $conn->error;
                            header('Location:invio.php');
                            die();
                        }
                        $sql = "INSERT INTO viaggio_veicolo (CodVeicolo, CodViaggio, Importo) 
                        VALUES ('$veicolo_viaggio ', '$last_id', '$costo_veicolo')";
                        if ($conn->query($sql) === TRUE) {
                            $last_id1 = $conn->insert_id; // Ottieni l'ID appena generato
                        } else {
                            $_SESSION['message1'] = "Errore nell'inserimento nella tabella2: " . $conn->error;
                            header('Location:invio.php');
                            die();
                        }
                        // Inserimento nella tabella2 con la chiave esterna
                        $sql = "INSERT INTO spesa_viaggio (CodViaggio, Motivo, Importo, CodViaggio_veicolo) 
                        VALUES ('$last_id', 'Alloggio', '$costo_alloggio', '$last_id1')";
                        if ($conn->query($sql) === TRUE) {
                            echo "Record inseriti con successo";
                        } else {
                            $_SESSION['message1'] = "Errore nell'inserimento nella tabella2: " . $conn->error;
                            header('Location:invio.php');
                            die();
                        }

                        $sql = "INSERT INTO spesa_viaggio (CodViaggio, Motivo, Importo, CodViaggio_veicolo) 
                        VALUES ('$last_id', 'Cibo', ' $costo_cibo', '$last_id1')";
                        if ($conn->query($sql) === TRUE) {
                            echo "Record inseriti con successo";
                        } else {
                            $_SESSION['message1'] = "Errore nell'inserimento nella tabella2: " . $conn->error;
                            header('Location:invio.php');
                            die();
                        }
                        $sql = "INSERT INTO spesa_viaggio (CodViaggio, Motivo, Importo, CodViaggio_veicolo) 
                        VALUES ('$last_id', 'Volo', '$costo_volo', '$last_id1')";
                        if ($conn->query($sql) === TRUE) {
                            echo "Record inseriti con successo";
                        } else {
                            $_SESSION['message1'] = "Errore nell'inserimento nella tabella2: " . $conn->error;
                            header('Location:invio.php');
                            die();
                        }
                        $sql = "INSERT INTO spesa_viaggio (CodViaggio, Motivo, Importo, CodViaggio_veicolo) 
                        VALUES ('$last_id', 'Intrattenimento', '$costo_intrattenimento', '$last_id1')";
                        if ($conn->query($sql) === TRUE) {
                            echo "Record inseriti con successo";
                        } else {
                            $_SESSION['message1'] = "Errore nell'inserimento nella tabella2: " . $conn->error;
                            header('Location:invio.php');
                            die();
                        }


                        $_SESSION['message1'] = "Viaggio inserito con successo";
                        header('Location:invio.php');
                        die();

                    }

                    
                } else {
                    $nome_immobile = mysqli_real_escape_string($conn, $_POST["nome-immobile"]);
                    $tipo_immobile = mysqli_real_escape_string($conn, $_POST["tipo-immobile"]);
                    $posizione_immobile = mysqli_real_escape_string($conn, $_POST["posizione-immobile"]);
                    $nome = $tipo_immobile . " " . $nome_immobile;
                    $query = "INSERT INTO immobile (Nome, Posizione)
                    VALUES ('$nome', '$posizione_immobile')";
                    if($conn->query($query) === TRUE){
                        header('Location:invio.php');
                        $_SESSION['message1'] = "Immobile inserito con successo";
                        die();
                    }else{
                        $_SESSION['message1'] = "Inserimento immobile errore" . $conn->error;
                    }
                }
            } else {
                $nome_veicolo = mysqli_real_escape_string($conn, $_POST["nome-veicolo"]);
                $tipo_veicolo = mysqli_real_escape_string($conn, $_POST["tipo-veicolo"]);
                $query = "INSERT INTO veicolo (Nome, Tipo)
                    VALUES ('$nome_veicolo', '$tipo_veicolo')";
                    if($conn->query($query) === TRUE){
                        header('Location:invio.php');
                        $_SESSION['message1'] = "Veicolo inserito con successo";
                        die();
                    }else{
                        echo "Inserimento dati lavoratore errore".$conn->error;
                        $_SESSION['message1'] = "Inserimento veicolo errore" . $conn->error;
                    }
            }
            
        } else {
            $_SESSION['message1'] = "VIETATO";
            header('Location:invio.php');
            die();
        }
        ?>
        <?php include "../close_connection.php"; ?>
    </body>
</html>