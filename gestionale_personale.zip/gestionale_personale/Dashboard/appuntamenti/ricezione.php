<?php
session_start();
require '../../functions.php';
if (!isUserLoggedIn() || getUserEmail() != "Capo") {
    header('Location:../../login.php');
    die();
}
require '../../connection.php';
?>  
<!DOCTYPE html>
<html>
    <head>
        <title>Ricezione dati</title>
        <meta charset="UTF-8" />
    </head>
    <body>
        
        <h1>Ricezione dati</h1>
        <?php
        $p2 = true;
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
           
            $data = mysqli_real_escape_string($conn, $_POST["data"]);
           
            
            $ora = mysqli_real_escape_string($conn, $_POST["ora"]);
            
            
            $minuti = mysqli_real_escape_string($conn, $_POST["minuti"]);
            

            $time = $ora . ":" . $minuti . ":" . "00";
            $datatime = $data . " " . $time;
            
            
            
            $motivo = mysqli_real_escape_string($conn, $_POST["motivo"]);
            
            
            $luogo = mysqli_real_escape_string($conn, $_POST["luogo"]);
            
           
           
            $note = mysqli_real_escape_string($conn, $_POST["note"]);
            
            
            $telefono = $_POST["telefono"];

            
                $query = "INSERT INTO prenotazioni (motivo, luogo, datetime, telefono, note)
                VALUES('$motivo', '$luogo', '$datatime', '$telefono', '$note')";
                if($conn->query($query) === TRUE){
                    header('Location:tabella.php');
                    $_SESSION['risp'] = "Prenotazione inserita con successo";
                    die();
                }else{
                    echo "Inserimento errore".$conn->error;
                }
            
            
        } else {
            $_SESSION['risp'] = 'ERRORE';
            header('Location:tabella.php');
            die();
        }
        ?>
        <?php include "../close_connection.php"; ?>
    </body>
</html>