<?php
require 'developers.php';


?>  
<!Doctype html>
<html lang="it" data-bs-theme="auto">
  <head>
    <link rel="shortcut icon" href="../logo.png"/>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="nothing">
    <meta name="author" content="anonymous">
    <title>Tabella modifica</title>
  <!--Bootstrap-->
    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/headers/">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.16.9/xlsx.full.min.js"></script>

  </head>
  <style>
    body {
    margin: 1px;
    padding: 1px;
  }
  .form-inline {
    display: flex; 
    float: right;
    width: 275px;

  }

  .form-inline input[type="date"] {
    margin-right: 2px; /* Adjust spacing between inputs */
    margin-left: 2px; /* Adjust spacing between inputs */
  }

  .form-inline button {
    padding: 6px 12px;
    border: none;
    border-radius: 4px;
  }
  .container {
        max-width: 600px;
        margin: 50px auto;
        text-align: center;
      }

      .options {
        
        display: flex;
        justify-content: space-between;
      }

      .option {
        display: inline-block;
        padding: 10px 20px;
        background-color: #0d6efd;
        color: white;
        text-decoration: none;
        border: 1px solid #0d6efd;
        border-radius: 5px;
        transition: background-color 0.3s, color 0.3s;
      }

      .option:hover {
        background-color: #0d6efd;
        color: white;
}
textarea {
    width: 150px;
    height: 22px;
    padding-top: 0;
    position: relative;
  }

  /* Stile per la textarea ingrandita */
  textarea.expanded {
      width: 70%;
      height: 50%;
      z-index: 9999;
      top: 25%;
      left: 15%;
      position: absolute;
  }
</style>
  <body>
  <?php
  $var = 0;
  $var1 = 0;
  $tmp1 = '';
  if ($_SERVER["REQUEST_METHOD"] === "GET" && !empty($_GET['date1'])) {
    $date1 = mysqli_real_escape_string($conn, $_GET["date1"]);
  } else {
    $date1 = date('Y-m');
  }
  ?>


    <header>
    
      <form id="dateForm" action="info.php" method="GET">
      <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names..">
        <div class="form-inline">
          
          <button onclick="resetDateField()" type="submit" class="btn btn-secondary">Reset</button>
          <input type="month" value="<?php echo $date1;?>" class="form-control" name="date1" id="date1">
          <button type="submit" value="Submit" class="btn btn-primary">Invio</button>
        </div>
      </form> 
    </header>
    <?php
    // Query per contare le righe con lo stesso campo
    $sql1 = "SELECT motivo, luogo, datetime, telefono, note FROM prenotazioni WHERE DATE_FORMAT(datetime, '%Y-%m') = '$date1' ORDER BY datetime";
    $result1 = $conn->query($sql1);
    $output = [];
    $i = 0;
    if ($result1->num_rows > 0) {
        // Output dei risultati
        while($row = $result1->fetch_assoc()) {
            $output[$i]['Motivo'] = $row["motivo"];
            $output[$i]['Luogo'] = $row["luogo"];
            $output[$i]['Telefono'] = $row["telefono"];
            $data = explode(" ", $row["datetime"]);
            $output[$i]['Date'] = $data[0];
            if ($data[1] == '00:00:00') {
              $output[$i]['Time'] = "";
            } else {
              $output[$i]['Time'] = $data[1];
            }
            
            $output[$i]['Note'] = $row["note"];

            $i++;
        }
    } else {
        $output = "No Data Found";
    }


    ?>
  <main>
  <div>
      <?php echo $deleteMsg??''; ?>
      <table class="table table-striped table-hover" id="data-table">
        <thead><!--<tr><th scope="col">Id</th>-->
          <th scope="col">Data</th>  
          <th scope="col">Ora</th>  
          <th scope="col">Motivo</th>
          <th scope="col">Luogo</th> 
          <th scope="col">Telefono</th>
          <th scope="col">Note</th>
      </thead>
      <tbody>
        <?php  
          if($output != "No Data Found") {
            $sn=1;
            for ($i = 0; $i < count($output); $i++) {
                ?>
                  <tr>
                    <!--<td scope="row"><?php //echo $sn; ?></td>-->
                    <td><?php echo $output[$i]['Date'] ?></td>
                    <td><?php echo $output[$i]['Time'] ?></td>
                    <td><?php echo $output[$i]['Motivo']; ?></td>
                    <td><?php echo $output[$i]['Luogo']; ?></td>
                    <td><?php echo $output[$i]['Telefono']; ?></td>
                    
                    <td><textarea name='note' onclick='espandiTextarea(this)'><?php echo $output['Note']??''; ?></textarea></td>
                  </tr>
                <?php
                  $sn++;      
            }
          } else {
            ?>
            <tr>
              <td colspan="8">
          <?php echo "No Data Found"; ?>
              </td>
            <tr>
          <?php
          }
          
        
        ?>
          </tbody>
          </table>  
    </div>

    </main>
    <footer>
      <div class="container">
        <div class="options">
          <a href="tabella.php" class="option">Indietro</a>
        </div>
      </div>
      
    </footer>
      <?php
        if (!empty($_SESSION['risp'])) { ?>
        <script>
            window.alert('<?= $_SESSION['risp'] ?>');
        </script>
        <?php
            $_SESSION['risp'] = '';
        }
        ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.3.2/dist/chart.umd.js" integrity="sha384-eI7PSr3L1XLISH8JdDII5YN/njoSsxfbrkCTnJrzXt+ENP5MOVBxD+l6sEG4zoLp" crossorigin="anonymous"></script><script src="script.js"></script>
      <script>
        

        //textarea
        function espandiTextarea(textarea) {
    textarea.classList.add("expanded");
    textarea.focus();
    textarea.style.zIndex = "9999";
  }

  function rimpicciolisciTextarea(textarea) {
    textarea.classList.remove("expanded");
  }

  document.addEventListener("focusout", function(event) {
    if (event.target.tagName === "TEXTAREA") {
      rimpicciolisciTextarea(event.target);
    }
  });

  document.addEventListener("click", function(event) {
    if (event.target.tagName === "TEXTAREA") {
      espandiTextarea(event.target);
    }
  });
  //search
  //Search
  function myFunction() {
        // Declare variables
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("myInput");
        filter = input.value.toUpperCase();
        table = document.getElementById("data-table"); // Modifica questo ID in base all'ID della tua tabella
        tr = table.getElementsByTagName("tr");

        // Loop through all table rows, and hide those who don't match the search query
        for (i = 0; i < tr.length; i++) {
            // Modifica questa parte per adattarla alla tua tabella PHP
            // Estrarre la cella desiderata da ogni riga della tabella
            td = tr[i].getElementsByTagName("td")[2]; // Modifica l'indice [1] in base alla posizione della colonna che vuoi filtrare
            if (td) {
                txtValue = td.textContent || td.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    }
    //data mese
    function resetDateField() {
    document.getElementById("date1").value = "<?php echo date('Y-m'); ?>";
  }

  function changeDate(increment) {
    var currentDate = new Date('<?php echo $date1; ?>');
    currentDate.setDate(currentDate.getDate() + increment);
    var formattedDate = currentDate.toISOString().split('T')[0];
    document.getElementById("date1").value = formattedDate;
    document.getElementById("dateForm").submit();
  }
        </script>
  </body>
</html>
<!---->