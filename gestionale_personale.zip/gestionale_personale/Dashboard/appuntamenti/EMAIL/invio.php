
//INVIO EMAIL
                // File per memorizzare il valore della variabile
                $filename = 'valore_variabile.txt';
                // Leggi il valore corrente dalla memoria o imposta un valore di default
                $valoreVariabile = file_exists($filename) ? intval(file_get_contents($filename)) : 0;

                // Ottieni la data corrente
                $dataCorrente = date('Y-m-d');
                // Ottieni la data dell'ultima modifica del file (se esiste)
                $dataUltimaModifica = file_exists($filename) ? date('Y-m-d', filemtime($filename)) : null;
                
                if ($dataCorrente > $dataUltimaModifica) {
                  $valoreVariabile = 0;
                }
                if ($valoreVariabile == 0) {
                  // Cambia il valore della variabile
                  $valoreVariabile++;

                  // Salva il nuovo valore nel file
                  file_put_contents($filename, $valoreVariabile);

                  $to = "casuf19@itisvinci.com";
                  $subject = "Fattura sta per scadere";

                  $message = "
                  <html>
                  <head>
                  <title>Fattura in scadenza</title>
                  </head>
                  <body>
                  <p>Fattura da pagare entra</p>
                  <table>
                  <tr>
                  <th>....</th>
                  <th>....</th>
                  </tr>
                  <tr>
                  <td>..</td>
                  <td>..</td>
                  </tr>
                  </table>
                  </body>
                  </html>
                  ";

                  // Always set content-type when sending HTML email
                  $headers = "MIME-Version: 1.0" . "\r\n";
                  $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

                  // More headers
                  $headers .= 'From: <casufederico4@gmail.com>' . "\r\n";
                  $headers .= 'Cc: casumoradei2023store@gmail.com' . "\r\n";

                  mail($to,$subject,$message,$headers);
                  echo "funziona";
                }
