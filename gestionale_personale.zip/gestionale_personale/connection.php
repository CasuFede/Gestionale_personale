<?php
    /*Connessione*/
    $server_name = "localhost";
    $user = "root";
    $password = "";
    $dbname = "progetto_appuntamenti";

    $conn = new mysqli($server_name, $user, $password, $dbname);

    if($conn->connect_error){
        die("Connection error".$conn->connect_error);
    }

?>
